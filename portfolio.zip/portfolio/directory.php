portfolio-website/
|-- index.php (Home Page)
|-- about.php (About Page)
|-- services.php (Services Page)
|-- portfolio.php (Portfolio Page)
|-- resume.php (Resume Page)
|-- contact.php (Contact Page)
|-- social.php (Social Handles Page)
|-- hobbies.php (Hobbies Page)
|-- assets/
    |-- css/
        |-- style.css
    |-- img/
    |-- js/
