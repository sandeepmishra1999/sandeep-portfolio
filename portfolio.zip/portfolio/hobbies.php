<?php include 'header.php'; ?>

<main>
    <section class="social">
        <h2>Social Handles</h2>
        <ul>
            <li><a href="https://www.linkedin.com/your-profile">LinkedIn</a></li>
            <li><a href="https://www.instagram.com/your-username">Instagram</a></li>
            <li><a href="https://www.behance.net/your-username">Behance</a></li>
            <!-- Add more social handles as needed -->
        </ul>
    </section>
</main>

<?php include 'footer.php'; ?>
