<footer>
        <!-- Footer content here -->
    </footer>
</body>
</html>
