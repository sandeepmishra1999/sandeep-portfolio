<?php include 'header.php'; ?>

<main>
    <section class="hero">
        <!-- Hero content here -->
    </section>
</main>

<?php include 'footer.php'; ?>
