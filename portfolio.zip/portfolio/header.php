<!DOCTYPE html>
<html>
<head>
    <title>Your Portfolio</title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="portfolio.php">Portfolio</a></li>
                <li><a href="resume.php">Resume</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="social.php">Social</a></li>
                <li><a href="hobbies.php">Hobbies</a></li>
            </ul>
        </nav>
    </header>
